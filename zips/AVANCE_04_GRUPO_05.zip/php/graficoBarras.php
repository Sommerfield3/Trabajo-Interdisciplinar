<!-- Styles -->
<link rel="stylesheet" href="../css/charts.css">

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

<div id="container" style="display:none">
    <?php echo $_GET["objeto"]?>
</div>

<!-- Chart code -->
<script src="../js/graficoBarras.js"></script>


<!-- HTML -->
<div id="chartdiv"></div>