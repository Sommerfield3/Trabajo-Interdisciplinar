<!-- Styles -->
<link rel="stylesheet" href="../css/charts.css">
    
<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/percent.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
    
<!-- Chart code -->

<div id="container">
    <?php echo $_GET['datos']?>
</div>
    
    <!-- HTML -->
<div id="chartdiv"></div>


<script src="../js/graficoPiePorAlumno.js"></script>    
