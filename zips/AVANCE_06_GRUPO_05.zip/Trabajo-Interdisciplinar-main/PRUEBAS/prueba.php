<?php
$Date = date('d_m_Y',time());  
echo "The current date and time are $Date.";
?>